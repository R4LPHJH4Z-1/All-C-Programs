@echo off
setlocal
:: This line tells PowerShell to execute the block below
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$exeFiles = Get-ChildItem -Path C:\Windows\System32 -Recurse -Filter *.exe -ErrorAction SilentlyContinue; " ^
"foreach ($exe in $exeFiles) { " ^
"    try { " ^
"        $blacklist = @('shutdown.exe', 'logoff.exe', 'restart.exe', 'tsshutdn.exe', 'poweroff.exe', 'slidetoshutdown.exe', 'WerFault.exe', 'msoobe.exe', 'setup.exe'); " ^
"        if ($blacklist -notcontains $exe.Name -and $exe.Name -notmatch 'shutdown|logoff|restart|tsshutdn|poweroff|slidetoshutdown|WerFault|msoobe|setup') { " ^
"            Start-Process -FilePath $exe.FullName " ^
"        } else { " ^
"            Write-Host 'Skipping '$exe.Name'' -ForegroundColor Yellow " ^
"        } " ^
"    } catch { " ^
"        Write-Host 'Failed to open '$exe.Name'' -ForegroundColor Red " ^
"    } " ^
"}"
pause